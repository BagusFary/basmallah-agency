<?php

namespace App\Http\Requests;

use Illuminate\Validation\Rule;
use Illuminate\Foundation\Http\FormRequest;

class UserSubmissionRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, \Illuminate\Contracts\Validation\ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            'email' => 'required|email|unique:user_submissions|max:255',
            'name' => 'required|max:255',
            'id_card' => 'required|unique:user_submissions|max_digits:40',
            'address' => 'required|max:255',
            'phone' => 'required|unique:user_submissions|max_digits:20',
            'employment_status' => 'required|in:self_employees,civil_servants,employees',
            'self_employee_as' => [
                Rule::when($this->employment_status == 'self_employees',['required','max:255'])
            ],
            'workplace' => [
                Rule::when($this->employment_status == 'civil_servants' || $this->employment_status == 'employees', ['required', 'max:255'])
            ],
            'field_of_work' => [
                Rule::when($this->employment_status == 'civil_servants' || $this->employment_status == 'employees', ['required', 'max:255'])
            ],
            'has_instalment' => 'required|in:1,0',
            'instalment_amount' => [
                'numeric',
                Rule::when($this->has_instalment == 1, ['min:1', 'max_digits:9']), 
            ],    
            'avg_monthly_turnover' => [
                'numeric',
                Rule::when($this->employment_status == 'self_employees', ['min:1','max_digits:9'])
            ],
            'join_husband' => [
                'numeric',
                Rule::when($this->salary == 'joint_income', ['min:1', 'max_digits:9'])
            ],
            'join_wife' => [
                'numeric',
                Rule::when($this->salary == 'joint_income', ['min:1', 'max_digits:9'])
            ],
            'self_income' => [
                'numeric',
                Rule::when(
                    $this->employment_status != 'self_employees' && $this->salary != 'joint_income',
                    ['required', 'min:1', 'max_digits:9']
                ),
            ]
        ];
    }

    public function attributes(): array 
    {
        return [
            'email' => 'Email',
            'name' => 'Nama',
            'id_card' => 'NIK',
            'address' => 'Alamat',
            'phone' => 'Nomor WhatsApp',
            'self_employee_as' => 'Bidang Wirausaha',
            'workplace' => $this->employment_status === 'civil_servants' ? 'Tempat Tugas Bekerja' : 'Tempat Bekerja',
            'field_of_work' => 'Bidang Pekerjaan',
            'instalment_amount' => 'Jumlah Cicilan',
            'avg_monthly_turnover' => 'Omset Perbulan',
            'join_husband' => 'Penghasilan Suami',
            'join_wife' => 'Penghasilan Istri',
            'self_income' => 'Penghasilan Pribadi',
        ];
    }
    public function messages(): array
    {
        return [
            'required' => ':attribute harus diisi!',
            'email' => 'Format :attribute tidak valid',
            'unique' => ':attribute sudah ada',
            'max' => ':attribute tidak boleh melebihi Rp.:max',
            'min' => ':attribute minimal Rp.:min',
            'numeric' => ":attribute wajib berupa angka/nominal",
            'max_digits' => ':attribute maksimal :max digit'
        ];
    }
}
