<div id="default-modal" data-modal-placement="top-left" tabindex="-1" aria-hidden="true"
    class="hidden overflow-y-auto overflow-x-hidden fixed top-0 right-0 left-0 z-50 justify-center items-center w-full md:inset-0 h-[calc(100%-1rem)] max-h-full">
    <div class="relative p-4 w-full max-w-2xl max-h-full">
        <div class="relative bg-white rounded-lg shadow-sm dark:bg-gray-700">
            <div
                class="flex items-center justify-between p-4 md:p-5 border-b rounded-t dark:border-gray-600 border-gray-200">
                <h3 class="text-xl font-semibold text-vintage-dark dark:text-white">
                    Syarat dan Ketentuan
                </h3>
                <button type="button"
                    class="text-gray-400 bg-transparent hover:bg-gray-200 hover:text-gray-900 rounded-lg text-sm w-8 h-8 ms-auto inline-flex justify-center items-center dark:hover:bg-gray-600 dark:hover:text-white"
                    data-modal-hide="default-modal">
                    <svg class="w-3 h-3" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="none"
                        viewBox="0 0 14 14">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 1 6 6m0 0 6 6M7 7l6-6M7 7l-6 6" />
                    </svg>
                    <span class="sr-only">Close modal</span>
                </button>
            </div>
            <div class="p-4 md:p-5 space-y-4">
                <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                    Nomor WhatsApp yang telah anda daftarkan hanya bisa melakukan <b>1 kali submit</b>.
                </p>
                <p class="text-base leading-relaxed text-gray-500 dark:text-gray-400">
                    Pastikan nomor yang digunakan sudah benar, karena tidak dapat diubah setelah pendaftaran.
                </p>
            </div>
            <div class="flex items-center p-4 md:p-5 border-t border-gray-200 rounded-b dark:border-gray-600">
                <button id="submit-submission" data-modal-hide="default-modal" type="submit"
                    class="text-white me-2 bg-vintage-dark focus:ring-4 focus:outline-none focus:ring-vintage-brem font-medium rounded-lg text-sm px-5 py-2.5 text-center ">Saya
                    yakin</button>
                <button data-modal-hide="default-modal" type="button"
                    class="py-2.5 px-5 ms-3 text-sm font-medium text-vintage-dark focus:outline-none bg-white rounded-lg border border-vintage-brem hover:bg-vintage-brem hover:text-vintage-light focus:z-10 focus:ring-4 focus:ring-vintage-dark">Kembali</button>
            </div>
        </div>
    </div>
</div>
