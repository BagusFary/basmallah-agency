@extends('components.layouts.landingpage')

@section('title', 'Basmallah Agency')

@section('description', 'Basmallah Agency merupakan Agen Properti yang sudah berjalan lama')

@push('scripts')
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.7/dist/gsap.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/gsap@3.12.7/dist/ScrollTrigger.min.js"></script>
@endpush

@section('content')
    <section id="container" class="transition bg-cover ease-in-out bg-center bg-no-repeat bg-vintage-brem bg-blend-multiply"
        style="background-image: url('{{ $heroImage ?? '' }}')">
        <div class="px-4 mx-auto max-w-screen-xl text-center py-24 lg:py-56">
            <h1 class="mb-4 text-4xl font-extrabold tracking-tight leading-none text-white md:text-5xl lg:text-6xl">
                {{ $content->hero_title ?? config('app.name') }}
            </h1>
            <div class="mb-8 text-md font-normal text-white lg:text-xl sm:px-16 lg:px-48">
                {!! str($content->hero_description)->markdown()->sanitizeHtml() !!}
            </div>
            <div class="flex flex-col space-y-4 sm:flex-row sm:justify-center sm:space-y-0">
                <a href="#house-list"
                    class="text-vintage-dark bg-vintage-light focus:ring-4 focus:ring-vintage-brem font-medium rounded-lg text-sm px-6 py-3.5 dark:bg-vintage-cream dark:hover:bg-vintage-light focus:outline-none dark:focus:ring-vintage-light dark:text-black">
                    Daftar
                </a>
                <a href="#faq"
                    class="inline-flex justify-center hover:text-gray-900 items-center py-3 px-5 sm:ms-4 text-sm font-medium text-center text-white rounded-lg border border-white hover:bg-gray-100 focus:ring-4 focus:ring-gray-400">
                    FAQ
                </a>
            </div>
        </div>
    </section>

    <svg xmlns="http://www.w3.org/2000/svg" class="" viewBox="0 0 1440 320">
        <path fill="#747264" fill-opacity="1"
            d="M0,160L60,176C120,192,240,224,360,202.7C480,181,600,107,720,101.3C840,96,960,160,1080,197.3C1200,235,1320,245,1380,250.7L1440,256L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z">
        </path>
    </svg>

    <section id="about" class=" antialiased">
        <div class="mx-auto grid max-w-screen-xl px-4 pb-8 md:grid-cols-12 lg:gap-12 lg:pb-16 xl:gap-0">
            <div class="content-center justify-self-start md:col-span-7 md:text-start">
                <h1
                    class="mb-4 text-4xl font-extrabold leading-none text-black tracking-tight dark:text-white md:max-w-2xl md:text-5xl xl:text-6xl">
                    Kenapa Pilih<br />
                    <span class="text-vintage-dark">
                        Basmallah Agency?
                    </span>

                </h1>
                <div class="mb-4 max-w-2xl text-black dark:text-gray-400 md:mb-12 md:text-lg mb-3 lg:mb-5 lg:text-xl">
                    {{ $content->about_description ?? 'Unknown Text.' }}
                </div>
            </div>
            <div class="hidden md:col-span-5 md:mt-0 md:flex">
                <img id="img-hero" class="dark:hidden" src="{{ asset('Hero Images.png') }}" alt="shopping illustration" />
            </div>
        </div>
        <div class="grid gap-3">
            <h1 class="text-vintage-dark dark:text-white text-center text-2xl font-bold">Partner Kami</h1>
            <div
                class="mx-auto grid max-w-screen-xl grid-cols-{{ $housingPartnersTotal }} gap-8 text-gray-500 dark:text-gray-400 sm:grid-cols-{{ $housingPartnersTotal }} sm:gap-12 lg:grid-cols-{{ $housingPartnersTotal }} px-4">
                @foreach ($housingPartners as $partner)
                    <a href="#" class="flex items-center md:justify-center">
                        <h1
                            class="h-6 text-vintage-brem hover:text-vintage-dark dark:hover:text-white font-bold text-sm max-md:scale-75 md:text-3xl">
                            {{ $partner }}
                        </h1>
                    </a>
                @endforeach
            </div>
        </div>
        <svg xmlns="http://www.w3.org/2000/svg" class="-mb-3" viewBox="0 0 1440 320">
            <path fill="#3C3633" fill-opacity="1"
                d="M0,160L60,176C120,192,240,224,360,202.7C480,181,600,107,720,101.3C840,96,960,160,1080,197.3C1200,235,1320,245,1380,250.7L1440,256L1440,320L1380,320C1320,320,1200,320,1080,320C960,320,840,320,720,320C600,320,480,320,360,320C240,320,120,320,60,320L0,320Z">
            </path>
        </svg>
    </section>

    <section class="bg-vintage-dark py-8 antialiased md:py-16 px-3">
        <div class="container mx-auto">
            <div class=" uppercase opacity-0 text-vintage-dark font-bold text-center w-full my-5 highlight-1">
                <span class="bg-white p-1 text-lg md:text-2xl">Hanya disini!</span>
            </div>
            <div class=" text-center text-white">
                <h1 class="text-xl md:text-4xl font-bold uppercase">Hadiah Souvenir Menarik!</h1>
                <span class="text-small font-light text-vintage-light mt-2">
                    Dapatkan hadiah menarik dengan mendaftar melalui
                    <b>Basmallah Agency</b>. <span class="underline">S&K</span></span>
            </div>
            <div class=" uppercase opacity-0 text-vintage-dark font-bold text-center w-full my-5 highlight-2">
                <a href="#house-list" class="bg-white p-1 text-lg md:text-2xl">Daftar Sekarang</a>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 content-center">
                <div class="flex flex-col justify-center items-center relative">
                    <img id="souvenir-1" src="{{ asset('souvenir/souvenir (1).png') }}" class="scale-75 md:scale-100"
                        alt="">
                    <span id="text-souvenir-1"
                        class="bg-white text-vintage-dark px-3 text-lg md:text-2xl font-bold uppercase text-center">Goto
                        Moko Alat Pel</span>
                </div>
                <div class="flex flex-col justify-center items-center">
                    <img id="souvenir-2" src="{{ asset('souvenir/souvenir (2).png') }}" class="scale-75 md:scale-75"
                        alt="">
                    <span id="text-souvenir-2"
                        class="bg-white text-vintage-dark px-3 text-lg md:text-2xl font-bold uppercase text-center">Satu
                        Keluarga Dispenser Beras</span>
                </div>
                <div class="flex flex-col justify-center items-center col-span-full">
                    <img id="souvenir-3" src="{{ asset('souvenir/souvenir (3).png') }}" class="scale-75 md:scale-75"
                        alt="">
                    <span id="text-souvenir-3"
                        class="bg-white text-vintage-dark px-3 text-lg md:text-2xl font-bold uppercase text-center">VISHAL
                        Silicone Set Kitchen Utensil</span>
                </div>
            </div>
        </div>
    </section>
    <section class="bg-vintage-light">
        <svg xmlns="http://www.w3.org/2000/svg" class="" viewBox="0 0 1440 320">
            <path fill="#3C3633" fill-opacity="1"
                d="M0,160L60,176C120,192,240,224,360,202.7C480,181,600,107,720,101.3C840,96,960,160,1080,197.3C1200,235,1320,245,1380,250.7L1440,256L1440,0L1380,0C1320,0,1200,0,1080,0C960,0,840,0,720,0C600,0,480,0,360,0C240,0,120,0,60,0L0,0Z">
            </path>
        </svg>
        <div id="house-list" class="py-8 px-4 mx-auto max-w-screen-xl lg:py-16 ">
            <div class="mx-auto max-w-screen-sm text-center mb-8 lg:mb-16">
                <h2 class="mb-4 text-4xl tracking-tight font-extrabold text-vintage-dark dark:text-white">List Perumahan
                </h2>
                <p class="font-light text-vintage-dark lg:mb-16 sm:text-xl dark:text-gray-400">
                    Pilih rumah favorit Anda dan lakukan submission untuk berkesempatan mendapatkan rumah impian Anda!
                </p>
            </div>
            <div class="grid gap-8 mb-6 lg:mb-16 md:grid-cols-2">
                @if (count($houseLists) == 0)
                    <div class="col-span-full">
                        <h1 class="text-lg text-center text-vintage-dark font-bold">Perumahan Belum Tersedia</h1>
                    </div>
                @endif
                @foreach ($houseLists as $house)
                    <article
                        class="flex flex-col relative md:flex-row border border-vintage-brem border-rounded drop-shadow-xl shadow-vintage-brem grid-rows-4 items-stretch bg-white rounded-lg">
                        @if ($house->available < 1)
                            <div class="bg-vintage-dark/70 w-full h-full z-40 absolute top-0 left-0">
                                <h1 class="flex items-center w-full h-full justify-center text-white font-bold">Tidak
                                    Tersedia</h1>
                            </div>
                        @endif

                        <div class="relative">
                            <a href="{{ str_contains($house->instagram, 'https') ? $house->instagram : ("https://www.instagram.com/" . $house->instagram)}}">
                                <img class="w-full md:min-w-64 md:max-w-64 h-[200px] object-center md:h-md md:rounded-lg sm:rounded-none rounded-t-lg md:rounded-b-md  object-cover"
                                    src="{{ asset("storage/$house->image_url") }}" alt="Bonnie Avatar">
                            </a>
                        </div>
                        <div class="">
                            <div class="px-3 flex flex-col gap-3 self-stretch h-full">
                                <h3 class="text-xl font-bold">
                                    <h1 class="font-bold text-lg text-vintage-dark dark:text-white md:text-2xl">
                                        {{ $house->name }}
                                    </h1>
                                </h3>
                                <div class="grid">
                                    <div class="inline-flex items-center">
                                        <span
                                            class="text-white bg-vintage-dark border border-vintage-dark font-medium px-2.5 py-0.5 dark:bg-green-900 dark:text-green-300">DP
                                            {{ $house->down_payment }}%</span>
                                        <p
                                            class="font-light bg-white text-vintage-dark border border-vintage-dark px-2.5 py-0.5 dark:text-white">
                                            Tersisa <span class="font-semibold">
                                                {{ \Number::format($house->available, locale: 'id') }}</span>
                                        </p>
                                    </div>
                                    <p class="font-light text-black dark:text-white mb-5">
                                        Booking Fee <span class="font-semibold">Rp.
                                            {{ \Number::format($house->booking_fee, locale: 'id') }}</span>
                                    </p>
                                </div>



                                <div class="mt-auto mb-5">
                                    <a href="/housing-partners/{{ $house->id }}/submission"
                                        class="border-2 hover:-translate-2 font-bold text-vintage-dark hover:bg-vintage-dark hover:text-white border px-3 py-2 border-vintage-dark bg-transparent">
                                        Daftar Sekarang
                                    </a>
                                </div>
                            </div>
                        </div>
                    </article>
                @endforeach
            </div>
        </div>
    </section>


    <section id="faq" class=" antialiased bg-vintage-brem">
        <svg xmlns="http://www.w3.org/2000/svg" class="-mt-3" viewBox="0 0 1440 320">
            <path fill="#EEEDEB" fill-opacity="1"
                d="M0,256L40,229.3C80,203,160,149,240,144C320,139,400,181,480,208C560,235,640,245,720,234.7C800,224,880,192,960,192C1040,192,1120,224,1200,229.3C1280,235,1360,213,1400,202.7L1440,192L1440,0L1400,0C1360,0,1280,0,1200,0C1120,0,1040,0,960,0C880,0,800,0,720,0C640,0,560,0,480,0C400,0,320,0,240,0C160,0,80,0,40,0L0,0Z">
            </path>
        </svg>

        <div class="mx-auto max-w-screen-xl px-4 2xl:px-0 py-8">
            <div class="lg:flex lg:items-center lg:justify-between lg:gap-4">
                <h2 class="mb-4 text-lg md:text-4xl tracking-tight font-extrabold text-white dark:text-white">
                    Frequently
                    Ask &
                    Question</h2>
            </div>

            <div class="mt-6 flow-root">
                @if (empty($faqs->items()))
                    <h1 class="text-white text-lg">FAQ belum tersedia.</h1>
                @endif
                <div id="content-faq" class="-my-6 divide-y divide-white dark:divide-gray-800">
                    @foreach ($faqs->items() as $faq)
                        <div class="space-y-4 py-6 md:py-8">
                            <div class="grid gap-4">
                                <span class="text-xl font-semibold text-white dark:text-white">
                                    “{{ $faq->ask_question }}”</span>
                            </div>
                            <div class="text-base font-normal text-white dark:text-gray-400">
                                {!! $faq->answer !!}
                            </div>
                        </div>
                    @endforeach
                </div>
            </div>

            @if ($faqs->hasMorePages())
                <div id="{{ $faqs->nextCursor()->encode() }}"
                    class="next-button mt-6 flex items-center justify-center lg:justify-start">
                    <button id="btn-next-button" type="button"
                        class="w-full rounded-lg  bg-white px-5 py-2.5 text-sm font-medium text-vintage-dark sm:w-auto">
                        Lihat Banyak
                    </button>
                </div>
            @endif

        </div>

    </section>

    @push('scripts')
        <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      "mainEntity": [
        @foreach ($faqs->items() as $faq)
        {
        "@type": "Question",
        "name": "{{ $faq->ask_question }}",
        "acceptedAnswer": {
          "@type": "Answer",
          "text": "{{ $faq->answer }}"
            }
        }@if(!$loop->last),@endif
        @endforeach
      ]
    }
        </script>
    @endpush

@endsection
