<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('user_submissions', function (Blueprint $table) {
            $table->string('workplace')->nullable()->after('avg_monthly_turnover');
            $table->string('field_of_work')->nullable()->after('workplace');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('user_submissions', function (Blueprint $table) {
            $table->dropColumn('workplace');
            $table->dropColumn('field_of_work');
        });
    }
};
